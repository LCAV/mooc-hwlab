/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c for Voice Transformer via Granular Synthesis
  ******************************************************************************
  *
  * (c) 2020, LCAV, EPFL
  * paolo.prandoni@epfl.ch
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#define MUTE HAL_GPIO_WritePin(MUTE_GPIO_Port, MUTE_Pin, GPIO_PIN_SET);
#define UNMUTE HAL_GPIO_WritePin(MUTE_GPIO_Port, MUTE_Pin, GPIO_PIN_RESET);

#define SET_MIC_RIGHT HAL_GPIO_WritePin(LR_SEL_GPIO_Port, LR_SEL_Pin, GPIO_PIN_SET);
#define SET_MIC_LEFT HAL_GPIO_WritePin(LR_SEL_GPIO_Port, LR_SEL_Pin, GPIO_PIN_RESET);
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2S_HandleTypeDef hi2s1;
I2S_HandleTypeDef hi2s2;
DMA_HandleTypeDef hdma_spi1_tx;
DMA_HandleTypeDef hdma_spi2_rx;

TIM_HandleTypeDef htim2;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

// Benchmarking: visualize timer_value_us in debugger to see number of microseconds per sample
volatile int32_t timer_value_us;
#define START_TIMER {\
  HAL_TIM_Base_Init(&htim2);\
  HAL_TIM_Base_Start(&htim2); }
#define STOP_TIMER {\
  timer_value_us = 1000 * __HAL_TIM_GET_COUNTER(&htim2) / FRAMES_PER_BUFFER;\
  HAL_TIM_Base_Stop(&htim2); }

char user_button = 0;

// DMA buffers
#define SAMPLES_PER_FRAME 2     // mic returns a stereo signal via I2S
#define FRAMES_PER_BUFFER 32    // user-defined, small in this application

#define HALF_BUFFER_SIZE (FRAMES_PER_BUFFER * SAMPLES_PER_FRAME)
#define FULL_BUFFER_SIZE (2 * HALF_BUFFER_SIZE)

int16_t dma_rx[FULL_BUFFER_SIZE];
int16_t dma_tx[FULL_BUFFER_SIZE];

// Resampling constants
#define DARTH (2.0 / 3.0)
#define CHIPMUNK (3.0 / 2.0)

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_I2S1_Init(void);
static void MX_I2S2_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM2_Init(void);
/* USER CODE BEGIN PFP */

static void InitBuffer(float Alpha);
inline static void VoiceEffect(int16_t *pIn, int16_t *pOut, uint16_t size);

void Process(int16_t *pIn, int16_t *pOut, uint16_t size) {
  START_TIMER
  VoiceEffect(pIn, pOut, size);
  STOP_TIMER
}

// DMA callbacks
void HAL_I2S_RxHalfCpltCallback(I2S_HandleTypeDef *hi2s) {
}
void HAL_I2S_RxCpltCallback(I2S_HandleTypeDef *hi2s) {
}
void HAL_I2S_TxHalfCpltCallback(I2S_HandleTypeDef *hi2s) {
    Process(dma_rx, dma_tx, HALF_BUFFER_SIZE);
}
void HAL_I2S_TxCpltCallback(I2S_HandleTypeDef *hi2s) {
    Process(dma_rx + HALF_BUFFER_SIZE, dma_tx + HALF_BUFFER_SIZE, HALF_BUFFER_SIZE);
}
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
  if (GPIO_Pin == B1_Pin) {
    // blue button pressed
    if (user_button) {
      user_button = 0;
      HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);  // LED off
      InitBuffer(DARTH);
    } else {
      user_button = 1;
      HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_SET);  // LED on
      InitBuffer(CHIPMUNK);
    }
  }
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */
  

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_I2S1_Init();
  MX_I2S2_Init();
  MX_USART2_UART_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */

  UNMUTE
  SET_MIC_LEFT

  InitBuffer(DARTH);

  // begin DMAs
  HAL_I2S_Transmit_DMA(&hi2s1, (uint16_t *) dma_tx, FULL_BUFFER_SIZE);
  HAL_I2S_Receive_DMA(&hi2s2, (uint16_t *) dma_rx, FULL_BUFFER_SIZE);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI48;
  RCC_OscInitStruct.HSI48State = RCC_HSI48_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI48;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART2;
  PeriphClkInit.Usart2ClockSelection = RCC_USART2CLKSOURCE_PCLK1;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2S1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2S1_Init(void)
{

  /* USER CODE BEGIN I2S1_Init 0 */

  /* USER CODE END I2S1_Init 0 */

  /* USER CODE BEGIN I2S1_Init 1 */

  /* USER CODE END I2S1_Init 1 */
  hi2s1.Instance = SPI1;
  hi2s1.Init.Mode = I2S_MODE_MASTER_TX;
  hi2s1.Init.Standard = I2S_STANDARD_PHILIPS;
  hi2s1.Init.DataFormat = I2S_DATAFORMAT_16B_EXTENDED;
  hi2s1.Init.MCLKOutput = I2S_MCLKOUTPUT_DISABLE;
  hi2s1.Init.AudioFreq = I2S_AUDIOFREQ_32K;
  hi2s1.Init.CPOL = I2S_CPOL_LOW;
  if (HAL_I2S_Init(&hi2s1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2S1_Init 2 */

  /* USER CODE END I2S1_Init 2 */

}

/**
  * @brief I2S2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2S2_Init(void)
{

  /* USER CODE BEGIN I2S2_Init 0 */

  /* USER CODE END I2S2_Init 0 */

  /* USER CODE BEGIN I2S2_Init 1 */

  /* USER CODE END I2S2_Init 1 */
  hi2s2.Instance = SPI2;
  hi2s2.Init.Mode = I2S_MODE_MASTER_RX;
  hi2s2.Init.Standard = I2S_STANDARD_PHILIPS;
  hi2s2.Init.DataFormat = I2S_DATAFORMAT_16B_EXTENDED;
  hi2s2.Init.MCLKOutput = I2S_MCLKOUTPUT_DISABLE;
  hi2s2.Init.AudioFreq = I2S_AUDIOFREQ_32K;
  hi2s2.Init.CPOL = I2S_CPOL_LOW;
  if (HAL_I2S_Init(&hi2s2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2S2_Init 2 */

  /* USER CODE END I2S2_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 48;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 0xFFFFFFFF;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 38400;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/** 
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void) 
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel2_3_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel2_3_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel2_3_IRQn);
  /* DMA1_Channel4_5_6_7_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel4_5_6_7_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel4_5_6_7_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, MUTE_Pin|LR_SEL_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : MUTE_Pin LR_SEL_Pin */
  GPIO_InitStruct.Pin = MUTE_Pin|LR_SEL_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : LD2_Pin */
  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI4_15_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI4_15_IRQn);

}

/* USER CODE BEGIN 4 */

// This is useful for debugging: pipe a 400Hz sinusoid into the granular synthesis algorithm
//  to verify the sound. To do so, just #define SINUSOIDAL_INPUT
//#define SINUSOIDAL_INPUT 1
#define COS_TABLE_LEN 72
static int16_t COS_TABLE[COS_TABLE_LEN] = {
  0x7FFF, 0x7F82, 0x7E0D, 0x7BA2, 0x7846, 0x7400, 0x6ED9, 0x68D9, 0x620C, 0x5A81, 0x5246, 0x496A,
  0x3FFF, 0x3617, 0x2BC6, 0x2120, 0x1639, 0x0B27, 0x0000, 0xF4D9, 0xE9C7, 0xDEE0, 0xD43A, 0xC9E9,
  0xC001, 0xB696, 0xADBA, 0xA57F, 0x9DF4, 0x9727, 0x9127, 0x8C00, 0x87BA, 0x845E, 0x81F3, 0x807E,
  0x8001, 0x807E, 0x81F3, 0x845E, 0x87BA, 0x8C00, 0x9127, 0x9727, 0x9DF4, 0xA57F, 0xADBA, 0xB696,
  0xC001, 0xC9E9, 0xD43A, 0xDEE0, 0xE9C7, 0xF4D9, 0x0000, 0x0B27, 0x1639, 0x2120, 0x2BC6, 0x3617,
  0x3FFF, 0x496A, 0x5246, 0x5A81, 0x620C, 0x68D9, 0x6ED9, 0x7400, 0x7846, 0x7BA2, 0x7E0D, 0x7F82};
static uint16_t cos_table_ix = 0;


// grain length; 1024 samples correspond to 32ms @ 32KHz
#define GRAIN_LEN 1024
// length of the tapering slope using 50% overlap
#define TAPER_LEN 384
#define GRAIN_STRIDE (GRAIN_LEN - TAPER_LEN)

// tapering slope, from 0 to 1 in TAPER_LEN steps
static int32_t TAPER[TAPER_LEN] = {
  0x0000, 0x0055, 0x00AA, 0x00FF, 0x0155, 0x01AA, 0x01FF, 0x0255, 0x02AA, 0x02FF, 0x0355, 0x03AA,
  0x03FF, 0x0455, 0x04AA, 0x04FF, 0x0555, 0x05AA, 0x05FF, 0x0655, 0x06AA, 0x06FF, 0x0755, 0x07AA,
  0x07FF, 0x0855, 0x08AA, 0x08FF, 0x0955, 0x09AA, 0x09FF, 0x0A55, 0x0AAA, 0x0AFF, 0x0B55, 0x0BAA,
  0x0BFF, 0x0C55, 0x0CAA, 0x0CFF, 0x0D55, 0x0DAA, 0x0DFF, 0x0E55, 0x0EAA, 0x0EFF, 0x0F55, 0x0FAA,
  0x0FFF, 0x1055, 0x10AA, 0x10FF, 0x1155, 0x11AA, 0x11FF, 0x1255, 0x12AA, 0x12FF, 0x1355, 0x13AA,
  0x13FF, 0x1455, 0x14AA, 0x14FF, 0x1555, 0x15AA, 0x15FF, 0x1655, 0x16AA, 0x16FF, 0x1755, 0x17AA,
  0x17FF, 0x1855, 0x18AA, 0x18FF, 0x1955, 0x19AA, 0x19FF, 0x1A55, 0x1AAA, 0x1AFF, 0x1B55, 0x1BAA,
  0x1BFF, 0x1C55, 0x1CAA, 0x1CFF, 0x1D55, 0x1DAA, 0x1DFF, 0x1E55, 0x1EAA, 0x1EFF, 0x1F55, 0x1FAA,
  0x1FFF, 0x2055, 0x20AA, 0x20FF, 0x2155, 0x21AA, 0x21FF, 0x2255, 0x22AA, 0x22FF, 0x2355, 0x23AA,
  0x23FF, 0x2455, 0x24AA, 0x24FF, 0x2555, 0x25AA, 0x25FF, 0x2655, 0x26AA, 0x26FF, 0x2755, 0x27AA,
  0x27FF, 0x2855, 0x28AA, 0x28FF, 0x2955, 0x29AA, 0x29FF, 0x2A55, 0x2AAA, 0x2AFF, 0x2B54, 0x2BAA,
  0x2BFF, 0x2C54, 0x2CAA, 0x2CFF, 0x2D54, 0x2DAA, 0x2DFF, 0x2E54, 0x2EAA, 0x2EFF, 0x2F54, 0x2FAA,
  0x2FFF, 0x3054, 0x30AA, 0x30FF, 0x3154, 0x31AA, 0x31FF, 0x3254, 0x32AA, 0x32FF, 0x3354, 0x33AA,
  0x33FF, 0x3454, 0x34AA, 0x34FF, 0x3554, 0x35AA, 0x35FF, 0x3654, 0x36AA, 0x36FF, 0x3754, 0x37AA,
  0x37FF, 0x3854, 0x38AA, 0x38FF, 0x3954, 0x39AA, 0x39FF, 0x3A54, 0x3AAA, 0x3AFF, 0x3B54, 0x3BAA,
  0x3BFF, 0x3C54, 0x3CAA, 0x3CFF, 0x3D54, 0x3DAA, 0x3DFF, 0x3E54, 0x3EAA, 0x3EFF, 0x3F54, 0x3FAA,
  0x3FFF, 0x4054, 0x40AA, 0x40FF, 0x4154, 0x41AA, 0x41FF, 0x4254, 0x42AA, 0x42FF, 0x4354, 0x43AA,
  0x43FF, 0x4454, 0x44AA, 0x44FF, 0x4554, 0x45AA, 0x45FF, 0x4654, 0x46AA, 0x46FF, 0x4754, 0x47AA,
  0x47FF, 0x4854, 0x48AA, 0x48FF, 0x4954, 0x49AA, 0x49FF, 0x4A54, 0x4AAA, 0x4AFF, 0x4B54, 0x4BAA,
  0x4BFF, 0x4C54, 0x4CAA, 0x4CFF, 0x4D54, 0x4DAA, 0x4DFF, 0x4E54, 0x4EAA, 0x4EFF, 0x4F54, 0x4FAA,
  0x4FFF, 0x5054, 0x50AA, 0x50FF, 0x5154, 0x51AA, 0x51FF, 0x5254, 0x52AA, 0x52FF, 0x5354, 0x53AA,
  0x53FF, 0x5454, 0x54AA, 0x54FF, 0x5554, 0x55A9, 0x55FF, 0x5654, 0x56A9, 0x56FF, 0x5754, 0x57A9,
  0x57FF, 0x5854, 0x58A9, 0x58FF, 0x5954, 0x59A9, 0x59FF, 0x5A54, 0x5AA9, 0x5AFF, 0x5B54, 0x5BA9,
  0x5BFF, 0x5C54, 0x5CA9, 0x5CFF, 0x5D54, 0x5DA9, 0x5DFF, 0x5E54, 0x5EA9, 0x5EFF, 0x5F54, 0x5FA9,
  0x5FFF, 0x6054, 0x60A9, 0x60FF, 0x6154, 0x61A9, 0x61FF, 0x6254, 0x62A9, 0x62FF, 0x6354, 0x63A9,
  0x63FF, 0x6454, 0x64A9, 0x64FF, 0x6554, 0x65A9, 0x65FF, 0x6654, 0x66A9, 0x66FF, 0x6754, 0x67A9,
  0x67FF, 0x6854, 0x68A9, 0x68FF, 0x6954, 0x69A9, 0x69FF, 0x6A54, 0x6AA9, 0x6AFF, 0x6B54, 0x6BA9,
  0x6BFF, 0x6C54, 0x6CA9, 0x6CFF, 0x6D54, 0x6DA9, 0x6DFF, 0x6E54, 0x6EA9, 0x6EFF, 0x6F54, 0x6FA9,
  0x6FFF, 0x7054, 0x70A9, 0x70FF, 0x7154, 0x71A9, 0x71FF, 0x7254, 0x72A9, 0x72FF, 0x7354, 0x73A9,
  0x73FF, 0x7454, 0x74A9, 0x74FF, 0x7554, 0x75A9, 0x75FF, 0x7654, 0x76A9, 0x76FF, 0x7754, 0x77A9,
  0x77FF, 0x7854, 0x78A9, 0x78FF, 0x7954, 0x79A9, 0x79FF, 0x7A54, 0x7AA9, 0x7AFF, 0x7B54, 0x7BA9,
  0x7BFF, 0x7C54, 0x7CA9, 0x7CFF, 0x7D54, 0x7DA9, 0x7DFF, 0x7E54, 0x7EA9, 0x7EFF, 0x7F54, 0x7FA9};

// local audio buffer length must be at least equal to the stride AND a power of two
#define BUF_LEN 1024
#define BUFLEN_MASK (BUF_LEN-1)
static int16_t buffer[BUF_LEN];

// input index for inserting DMA data
static uint16_t buf_ix = 0;
// index to beginning of current grain
static uint16_t curr_ix = 0;
// index to beginning of previous grain
static uint16_t prev_ix = BUF_LEN - GRAIN_STRIDE;
// index of sample within grain
static uint16_t grain_m = 0;

// rate change factor
static int32_t alpha = (int32_t)(0x7FFF * DARTH);


static void InitBuffer(float Alpha) {
  memset(buffer, 0, BUF_LEN * sizeof(int16_t));

  alpha = (int32_t)(0x7FFF * Alpha);
  // input index for inserting DMA data
  if (Alpha <= 1)
      buf_ix = 0;
  else
    buf_ix = (uint16_t)(GRAIN_LEN * (Alpha - 1) + 0.5) & BUFLEN_MASK;

  prev_ix = BUF_LEN - GRAIN_STRIDE;
  curr_ix = 0;
  grain_m = 0;
}


inline static int16_t Resample(uint16_t m, uint16_t start) {
  // non-integer index
  int32_t t = alpha * (int32_t)m;
  // anchor sample
  int16_t T = (int16_t)(t >> 15) + (int16_t)start;
  // fractional part
  int32_t tau = t & 0x07FFF;
  // compute linear interpolation
  int32_t y = (0x07FFF - tau) * buffer[T & BUFLEN_MASK] + tau * buffer[(T+1) & BUFLEN_MASK];
  return (int16_t)(y >> 15);
}


inline static void VoiceEffect(int16_t *pIn, int16_t *pOut, uint16_t size) {
  // put LEFT channel samples to mono buffer
  for (int n = 0; n < size; n += 2) {
#if defined(SINUSOIDAL_INPUT)
    buffer[buf_ix++] = COS_TABLE[cos_table_ix++] >> 2;
    if (cos_table_ix >= COS_TABLE_LEN)
      cos_table_ix = 0;
#else
    buffer[buf_ix++] = pIn[n];
#endif
    buf_ix &= BUFLEN_MASK;
  }

  // compute output samples
  for (int n = 0; n < size; n += 2) {
    // sample from current grain
    int16_t y = Resample(grain_m, curr_ix);
    // if we are in the overlap zone, compute sample from previous grain and mix using tapering slope
    if (grain_m < TAPER_LEN) {
      int32_t z = Resample(grain_m + GRAIN_STRIDE, prev_ix) * (0x07FFF - TAPER[grain_m]);
      z += y * TAPER[grain_m];
      y = (int16_t)(z >> 15);
    }
    ++grain_m;
    // if we are at the end of the stride, update buffer indices
    if (grain_m >= GRAIN_STRIDE) {
      grain_m = 0;
      prev_ix = curr_ix;
      curr_ix = (curr_ix + GRAIN_STRIDE) & BUFLEN_MASK;
    }
    pOut[n] = pOut[n+1] = y;
  }

  // optimized version that requires both GRAIN_STRIDE and TAPER_LEN to be
  //  exact multiples of the DMA half-buffer size:
  /*
  if (grain_m < TAPER_LEN) {
    // we are inside the tapering slope
    for (int n = 0; n < size; n += 2) {
      int32_t z = Resample(grain_m + GRAIN_STRIDE, prev_ix) * (0x07FFF - TAPER[grain_m]);
      z += Resample(grain_m, curr_ix) * TAPER[grain_m];
      pOut[n] = pOut[n+1] = (int16_t)(z >> 15);
      ++grain_m;
    }
  } else {
    for (int n = 0; n < size; n += 2)
      pOut[n] = pOut[n+1] = Resample(grain_m++, curr_ix);
  }
  // end of stride?
  if (grain_m >= GRAIN_STRIDE) {
    grain_m = 0;
    prev_ix = curr_ix;
    curr_ix = (curr_ix + GRAIN_STRIDE) & BUFLEN_MASK;
  }
  */
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(char *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
